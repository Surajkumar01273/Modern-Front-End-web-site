# javascript_practices
This practice javascript file.
<br>
Auther - Suraj kumar
